package com.example.myapplication1.model;

public class shoppingSpinnerList {
    String finishing_date, itemSelected, predictedDuration, purchase_date;
    int membersSelected, quantitySelected;

    public shoppingSpinnerList() {

    }

    public shoppingSpinnerList(String finishing_date, String itemSelected, String predictedDuration, String purchase_date, int membersSelected, int quantitySelected) {
        this.finishing_date = finishing_date;
        this.itemSelected = itemSelected;
        this.predictedDuration = predictedDuration;
        this.purchase_date = purchase_date;
        this.membersSelected = membersSelected;
        this.quantitySelected = quantitySelected;
    }

    public String getFinishing_date() {
        return finishing_date;
    }

    public void setFinishing_date(String finishing_date) {
        this.finishing_date = finishing_date;
    }

    public String getItemSelected() {
        return itemSelected;
    }

    public void setItemSelected(String itemSelected) {
        this.itemSelected = itemSelected;
    }

    public String getPredictedDuration() {
        return predictedDuration;
    }

    public void setPredictedDuration(String predictedDuration) {
        this.predictedDuration = predictedDuration;
    }

    public String getPurchase_date() {
        return purchase_date;
    }

    public void setPurchase_date(String purchase_date) {
        this.purchase_date = purchase_date;
    }

    public int getMembersSelected() {
        return membersSelected;
    }

    public void setMembersSelected(int membersSelected) {
        this.membersSelected = membersSelected;
    }

    public int getQuantitySelected() {
        return quantitySelected;
    }

    public void setQuantitySelected(int quantitySelected) {
        this.quantitySelected = quantitySelected;
    }
}
