package com.example.myapplication1.Interface;

import com.example.myapplication1.model.shoppingSpinnerList;

import java.util.List;

public interface IFirebaseLoadDoneShoppingList {

    void onFirebaseLoadShoppingListSuccess(List<shoppingSpinnerList> shoppingSpinnerListList);
    void onFirebaseLoadShoppingListFailed(String message);
}
