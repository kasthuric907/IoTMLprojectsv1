package com.example.myapplication1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;

import android.os.Build;
import android.os.Bundle;

import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication1.Interface.IFirebaseLoadDone;
import com.example.myapplication1.model.itemSpinnerList;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;

import java.io.UnsupportedEncodingException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import java.util.List;


public class tryCombining extends AppCompatActivity implements IFirebaseLoadDone, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    SearchableSpinner searchableSpinner;

    private FirebaseAuth addItem_FirebaseAuth;

    DatabaseReference itemsRef;
    IFirebaseLoadDone iFirebaseLoadDone;
    List<itemSpinnerList> items;

    Button btn_addItem, btn_regItem;
    EditText et_quantity, et_members;

    String selectedItem;


    //For mqtt

    DatabaseReference databaseReference;
    MqttAndroidClient client;
    TextView tv_Mqtt;


    //
    //gps

    private Location location;
    //private TextView tv_location;
    private GoogleApiClient googleApiClient;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private LocationRequest locationRequest;
    private static final long UPDATE_INTERVAL = 5000, FASTEST_INTERVAL = 5000;

    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissionsRejected = new ArrayList<>();
    private ArrayList<String> permissions = new ArrayList<>();

    private static final int ALL_PERMISSION_RESULT = 1011;

    //

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);
        searchableSpinner = (SearchableSpinner)findViewById(R.id.searchable_spinner_addItemsPage);

        btn_addItem = (Button) findViewById(R.id.btn_addItems_add);
        btn_regItem = (Button) findViewById(R.id.btn_reqItems_add);

        et_quantity = (EditText) findViewById(R.id.et_additems_quantity);
        et_members = (EditText) findViewById(R.id.et_additems_members);

        itemsRef = FirebaseDatabase.getInstance().getReference("Items");

        iFirebaseLoadDone = this;

        addItem_FirebaseAuth = FirebaseAuth.getInstance();
        //DBaddItemRef = FirebaseDatabase.getInstance().getReference("userInformatioin" + FirebaseAuth.getInstance().getUid());


        //gps

        //tv_location = findViewById(R.id.tv_location);

        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);

        permissionsToRequest = permissionsToRequest(permissions);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (permissionsToRequest.size() > 0) {
                requestPermissions(permissionsToRequest.toArray(new String[permissionsToRequest.size()]), ALL_PERMISSION_RESULT);
            }

        }

        googleApiClient = new GoogleApiClient.Builder(this).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();

        //

        //MQTT
        String clientId= MqttClient.generateClientId();
        client=new MqttAndroidClient(getApplicationContext(),"tcp://iot.eclipse.org:1883",clientId);
        tv_Mqtt = findViewById(R.id.tv_mqtt);
        //



        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(tryCombining.this, MainActivity.class));
        }

        itemsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                List<itemSpinnerList> items = new ArrayList<>();

                for (DataSnapshot itemSnapShot:dataSnapshot.getChildren()) {
                    items.add(itemSnapShot.getValue(itemSpinnerList.class));
                }

                iFirebaseLoadDone.onFirebaseLoadSuccess(items);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                iFirebaseLoadDone.onFirebaseLoadFailed(databaseError.getMessage());
            }
        });

        //mqtt


        try {
            IMqttToken token= client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //we are connected
                    Log.i("MqttApp","Connected succesfully");
                    Toast.makeText(tryCombining.this, "Connected succesfully", Toast.LENGTH_SHORT).show();

                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

                    //we are connected
                    Log.i("MqttApp","Connected failed");
                    Toast.makeText(tryCombining.this, "Connected failed", Toast.LENGTH_SHORT).show();

                }
            });
        }catch(MqttException e){
            e.printStackTrace();
        }


        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                Toast.makeText(tryCombining.this, "Connection lost", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                topic = "foo/try7";
                tv_Mqtt.setText(new String(message.getPayload()));

            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Toast.makeText(tryCombining.this, "Delivered succesfully"+token.toString(), Toast.LENGTH_SHORT).show();

            }
        });


        //



        btn_addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Refrence
                //int n = Integer.parseInt(x.getText().toString());

                String selectedItem = searchableSpinner.getSelectedItem().toString();

                String sq = et_quantity.getText().toString();
                String sm = et_members.getText().toString();

                if(TextUtils.isEmpty(sq)) {
                    Toast.makeText(tryCombining.this, "Please enter the quantity.", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(TextUtils.isEmpty(sm)) {
                    Toast.makeText(tryCombining.this, "Please enter the number of member using it", Toast.LENGTH_SHORT).show();
                    return;
                }

                int selected_quantity = Integer.parseInt(sq);
                int selected_members = Integer.parseInt(sm);

                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                String purchase_date = df.format(Calendar.getInstance().getTime());

                //Log.i("selected quantity", "onClick: " + selected_quantity);
                //Log.i("selected members", "onClick: " + selected_members);

                addItemForm itemInfo = new addItemForm(selectedItem, selected_quantity, selected_members, purchase_date);

                DateFormat dftf = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm:ss");
                String dateTime = dftf.format(Calendar.getInstance().getTime());

                if(selected_quantity < 1) {
                    Toast.makeText(tryCombining.this, "Please enter the quantity.", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if (selected_members < 1) {
                    Toast.makeText(tryCombining.this, "Please enter the number of members using it.", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(selectedItem.equals("select")){
                    Toast.makeText(tryCombining.this, "Select an iteam", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {

                    //SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                    //String formattedDate = df.format(Calendar.getInstance().getTime());

                    //DateFormat tf = new SimpleDateFormat("h:mm a");
                    //String formattedTime = tf.format(Calendar.getInstance().getTime());

                    ///DateFormat dftf = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm:ss");
                    ///String dateTime = dftf.format(Calendar.getInstance().getTime());

                    //Log.i("Date", "onClick: " +formattedDate);

                    addItemForm itemForm = new addItemForm(selectedItem, selected_quantity, selected_members, purchase_date);

                    FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("itemsAdded").child(dateTime).setValue(itemInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            Toast.makeText(tryCombining.this, "Item added Successfully.", Toast.LENGTH_SHORT).show();
                            //System.exit(0);
                        }
                    });


                    FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("itemsHistory").child(dateTime).setValue(itemInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            //Toast.makeText(tryCombining.this, "Add another item.", Toast.LENGTH_SHORT).show();
                            //System.exit(0);
                        }
                    });

                    //String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());
                    //Log.i("date and time", "onClick: " + currentDateTimeString);

                }


                Log.i("uid", "onClick: " + FirebaseAuth.getInstance().getUid());

                String topic = "foo/try7";
                String payload = FirebaseAuth.getInstance().getUid() + " " + selectedItem + " " + selected_quantity + " " + selected_members + " " + df.format(Calendar.getInstance().getTime()) + " " + dftf.format(Calendar.getInstance().getTime());
                Log.i("MQTT payload string", "onClick: " + payload);
                byte[] encodedPayload=new byte[0];
                try{
                    encodedPayload = payload.getBytes("UTF-8");
                    MqttMessage message = new MqttMessage((encodedPayload));
                    client.publish(topic,message);

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (MqttPersistenceException e) {
                    e.printStackTrace();
                } catch (MqttException e) {
                    e.printStackTrace();
                }
                startActivity(new Intent(tryCombining.this, homePage.class));
                finish();
            }

        });

        btn_regItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(tryCombining.this, ReqItem.class));
                finish();
            }

        });

    }

    @Override
    public void onFirebaseLoadSuccess(List<itemSpinnerList> itemSpinnerListList) {
        items = itemSpinnerListList;

        List<String> name_list = new ArrayList<>();

        for (itemSpinnerList item:itemSpinnerListList){
            name_list.add(item.getName());
        }
        //Log.i("kaisar", "onFirebaseLoadSuccess: " + name_list);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, name_list);
        searchableSpinner.setAdapter(adapter);

        selectedItem = searchableSpinner.getSelectedItem().toString();

    }



    @Override
    public void onFirebaseLoadFailed(String message) {

    }

    private ArrayList<String> permissionsToRequest(ArrayList<String> wantedPermissions) {
        ArrayList<String> result = new ArrayList<>();

        for (String perm : wantedPermissions) {
            if(!hasPermission(perm)) {
                result.add(perm);
            }
        }

        return result;
    }

    private boolean hasPermission(String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
        }

        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();

        if(googleApiClient != null) {
            googleApiClient.connect();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!checkPlayServices()) {
            //tv_location.setText("You need to install google play Services");
            Toast.makeText(this, "You need to install google play Services", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (googleApiClient != null && googleApiClient.isConnected()) {

            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, this);
            googleApiClient.disconnect();

        }
    }


    private boolean checkPlayServices() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);

        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST);
            }
            else {
                finish();
            }
            return false;
        }
        return true;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        location = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);

        if(location != null) {
            //tv_location.setText("Latitude: " + location.getLatitude() + "\nLongitude:" + location.getLongitude());
            int intLongitude = (int) location.getLongitude();
            int intLatitude = (int) location.getLatitude();
            Log.i("coordinates", "onConnected: " + intLatitude + intLongitude);
        }
        StartLocationUpdates();
    }


    private void StartLocationUpdates() {
        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(UPDATE_INTERVAL);
        locationRequest.setFastestInterval(FASTEST_INTERVAL);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "You need to provide permission to display location", Toast.LENGTH_SHORT).show();
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, this);



    }


    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@ NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

        if(location != null) {
            //tv_location.setText("Latitude: " + location.getLatitude() + "\nLongitude:" + location.getLongitude());
            int intLongitude = (int) location.getLongitude();
            int intLatitude = (int) location.getLatitude();
            Log.i("coordinates", "onConnected: " + intLatitude + intLongitude);
        }
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode) {

            case ALL_PERMISSION_RESULT:

                for (String perms : permissionsToRequest) {
                    if (!hasPermission(perms)) {
                        permissionsRejected.add(perms);
                    }
                }

                if (permissionsRejected.size() > 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(permissionsRejected.get(0))) {
                            new AlertDialog.Builder(tryCombining.this).setMessage("These Permissions are neccessary ").setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        requestPermissions(permissionsRejected.toArray(new String[permissionsRejected.size()]), ALL_PERMISSION_RESULT);
                                    }
                                }
                            }).setNegativeButton("Cancle", null).create().show();

                            return;
                        }
                    }
                }
                else {

                    if (googleApiClient != null) {
                        googleApiClient.connect();
                    }

                }

                break;

        }

    }


}
