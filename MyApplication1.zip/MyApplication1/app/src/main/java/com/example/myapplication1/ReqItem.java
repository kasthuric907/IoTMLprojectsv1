package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ReqItem extends AppCompatActivity {

    EditText etReqItems_req;
    Button btnReqItems_req;

    //private FirebaseAuth ReqItem_FirebaseAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_req_item);

        etReqItems_req = (EditText) findViewById(R.id.et_reqItemPage_req);
        btnReqItems_req = (Button) findViewById(R.id.btn_reqItemPage_req);


        btnReqItems_req.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String requestedItem = etReqItems_req.getText().toString().trim();

                if(TextUtils.isEmpty(requestedItem)) {
                    Toast.makeText(ReqItem.this, "Enter the requested item name.", Toast.LENGTH_SHORT).show();
                }
                else {

                    DateFormat dftf = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
                    String dateTime = dftf.format(Calendar.getInstance().getTime());

                    FirebaseDatabase.getInstance().getReference("requestedItems").child(FirebaseAuth.getInstance().getUid() + "_" + dateTime).setValue(requestedItem);
                    Toast.makeText(ReqItem.this, "Item Request Successful", Toast.LENGTH_SHORT).show();
                    //startActivity(new Intent(ReqItem.this, homePage.class));
                    finish();
                }
            }
        });
    }
}
