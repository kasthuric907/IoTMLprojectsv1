package com.example.myapplication1.model;

public class itemSpinnerList {
    String name;

    public itemSpinnerList() {
    }

    public itemSpinnerList(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
