package com.example.myapplication1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private static final int time_limit = 2000;
    private static long backPressed;

    RelativeLayout relativeLayout1, relativeLayout2;
    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            relativeLayout1.setVisibility(View.VISIBLE);
            relativeLayout2.setVisibility(View.VISIBLE);

        }
    };

    Button LoginButton, SignUpButton, ForgotPwdButton;
    EditText LoginEmail_et, LoginPwd_et;

    private FirebaseAuth Login_FirebaseAuth;

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = Login_FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            startActivity(new Intent(MainActivity.this, homePage.class));
            finish();
        }
        //updateUI(currentUser);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        relativeLayout1 = (RelativeLayout) findViewById(R.id.rel_lay1);
        relativeLayout2 = (RelativeLayout) findViewById(R.id.rel_lay2);

        handler.postDelayed(runnable, 2000);

        LoginButton = findViewById(R.id.btn_login);
        SignUpButton = findViewById(R.id.btn_signUp);
        ForgotPwdButton = findViewById(R.id.btn_forgotPsw);

        LoginEmail_et = findViewById(R.id.et_email);
        LoginPwd_et = findViewById(R.id.et_pwd);

        Login_FirebaseAuth = FirebaseAuth.getInstance();


        //login for an already registered user
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //to home page on successful login
            public void onClick(View v) {
                String str_loginEmail = LoginEmail_et.getText().toString().trim();
                String str_LoginPwd = LoginPwd_et.getText().toString().trim();

                if(TextUtils.isEmpty(str_loginEmail)) {
                    Toast.makeText(MainActivity.this, "Enter a valid email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(str_LoginPwd) || str_LoginPwd.length() < 8) {
                    Toast.makeText(MainActivity.this, "Enter a valid password", Toast.LENGTH_SHORT).show();
                    return;
                }

                Login_FirebaseAuth.signInWithEmailAndPassword(str_loginEmail, str_LoginPwd)
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    startActivity(new Intent(getApplicationContext(), homePage.class));
                                    Toast.makeText(MainActivity.this, "Logged in Successfully.", Toast.LENGTH_SHORT).show();
                                    finish();

                                } else {

                                    Toast.makeText(MainActivity.this, "Login failed. Please Check your email and password. Check if you are connected to internet", Toast.LENGTH_SHORT).show();
                                    //startActivity(new Intent(MainActivity.this, SignUp.class));
                                    return;
                                }
                            }
                        });

            }
        });


        //to sign up page
        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SignUp.class));
                finish();
            }
        });


        ForgotPwdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, forgotPwd.class));
                finish();
            }
        });

    }

}
