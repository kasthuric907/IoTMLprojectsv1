package com.example.myapplication1.Interface;

import com.example.myapplication1.model.itemSpinnerList;

import java.util.List;

public interface IFirebaseLoadDone {

    void onFirebaseLoadSuccess(List<itemSpinnerList> itemSpinnerListList);
    void onFirebaseLoadFailed(String message);
}
