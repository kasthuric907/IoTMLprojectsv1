package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class homePage extends AppCompatActivity {

    private static final int time_limit = 2000;
    private static long backPressed;

    CardView cv_home_profile, cv_home_addItems, cv_home_shopingList;


    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        cv_home_profile = (CardView)findViewById(R.id.cv_profile);
        cv_home_addItems = (CardView)findViewById(R.id.cv_HOME_addItem);
        cv_home_shopingList = (CardView) findViewById(R.id.cv_HOME_shopingList);

        //if (FirebaseAuth.getInstance().getCurrentUser() == null) {
        //    startActivity(new Intent(homePage.this, MainActivity.class));
        //}

        cv_home_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homePage.this, profilePage.class));
                finish();
            }
        });

        cv_home_addItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homePage.this, tryCombining.class));
                //finish();
            }
        });

        cv_home_shopingList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homePage.this, tryShowing.class));
            }
        });

    }
}
