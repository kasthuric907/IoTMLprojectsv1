package com.example.myapplication1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

public class SignUp extends AppCompatActivity {

    Button signUp_btn;

    EditText RegEmail_et, RegPwd_et, RegConPwd_et;
    EditText RegFname_et, RegLname_et, RegAddress_et;

    private FirebaseAuth Reg_FirebaseAuth;

    DatabaseReference databaseReference_reg;
    //FirebaseDatabase firebaseDatabase_reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Reg_FirebaseAuth = FirebaseAuth.getInstance();

        databaseReference_reg = FirebaseDatabase.getInstance().getReference("userInformation"); //we here created frist instace of FirebaseDatabase

        signUp_btn = (Button)findViewById(R.id.btn_reg);
        RegEmail_et = (EditText)findViewById(R.id.et_sign_Email);
        RegPwd_et = (EditText)findViewById(R.id.et_sign_psw);
        RegConPwd_et = (EditText)findViewById(R.id.et_sign_Cpsw);
        RegAddress_et = (EditText)findViewById(R.id.et_sign_address);

        RegFname_et = (EditText)findViewById(R.id.et_sign_Fname);
        RegLname_et = (EditText)findViewById(R.id.et_sign_Lname);

        signUp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String str_regEmail = RegEmail_et.getText().toString().trim();
                String str_regPwd = RegPwd_et.getText().toString().trim();
                final String str_regConPwd = RegConPwd_et.getText().toString().trim();
                final String str_regFname = RegFname_et.getText().toString().trim();
                final String str_regLname = RegLname_et.getText().toString().trim();
                final String str_address = RegAddress_et.getText().toString().trim();

                if(TextUtils.isEmpty(str_regEmail)) {
                    Toast.makeText(SignUp.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(TextUtils.isEmpty(str_regPwd) || str_regPwd.length() < 8) {
                    Toast.makeText(SignUp.this, "Password should be minimum 8 characters", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(TextUtils.isEmpty(str_regFname ) || TextUtils.isEmpty(str_regLname)) {
                    Toast.makeText(SignUp.this, "Please enter your name.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(TextUtils.isEmpty(str_address)) {
                    Toast.makeText(SignUp.this, "Please enter the address.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(str_regPwd.equals(str_regConPwd)) {


                    Reg_FirebaseAuth.createUserWithEmailAndPassword(str_regEmail, str_regPwd)
                            .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        signUpFormFB userInfo = new signUpFormFB(str_regFname, str_regLname, str_regEmail, str_address, str_regConPwd);

                                        FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                FirebaseAuth.getInstance().signOut();
                                                Toast.makeText(SignUp.this, "Registered Successfully.", Toast.LENGTH_SHORT).show();
                                                finish();
                                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                            }
                                        });

                                    } else {

                                        Toast.makeText(SignUp.this, "Failed to register. Please try again.", Toast.LENGTH_SHORT).show();

                                    }

                                }
                            });

                }
            }
        });

    }
}
