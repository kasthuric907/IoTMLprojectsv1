package com.example.myapplication1;

public class addItemForm {

    public String itemSelected;
    public int quantitySelected, membersSelected;
    public String purchase_date;

    public addItemForm() {
    }

    public addItemForm(String itemSelected, int quantitySelected, int membersSelected, String purchase_date) {
        this.itemSelected = itemSelected;
        this.quantitySelected = quantitySelected;
        this.membersSelected = membersSelected;
        this.purchase_date = purchase_date;
    }
}
