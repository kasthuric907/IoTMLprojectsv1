package com.example.myapplication1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication1.Interface.IFirebaseLoadDoneShoppingList;
import com.example.myapplication1.model.itemSpinnerList;
import com.example.myapplication1.model.shoppingSpinnerList;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class tryShowing extends AppCompatActivity implements IFirebaseLoadDoneShoppingList {

    SearchableSpinner searchableSpinner;

    private FirebaseAuth addItem_FirebaseAuth;

    DatabaseReference itemsRef;
    IFirebaseLoadDoneShoppingList iFirebaseLoadDoneShoppingList;
    List<shoppingSpinnerList> items;

    String selectedItem;
    //BottomSheetDialogFragment

    TextView tv_purchase, tv_finish, tv_duration, tv_item, tv_members, tv_quantity;
    //FloatingActionButton btn_finished;


    boolean isFirstTimeClick = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_try_showing);

        searchableSpinner = (SearchableSpinner)findViewById(R.id.searchable_spinner_shoppingListPage);
        itemsRef = FirebaseDatabase.getInstance().getReference("userInformation/" + FirebaseAuth.getInstance().getUid() + "/itemsAdded");

        iFirebaseLoadDoneShoppingList = this;


        addItem_FirebaseAuth = FirebaseAuth.getInstance();


        final View bottom_sheet_dialog = getLayoutInflater().inflate(R.layout.purchase_item_detail, null);

        tv_duration = (TextView) findViewById(R.id.tv_Pduration);
        tv_finish = (TextView) findViewById(R.id.tv_Fdate);
        tv_item = (TextView) findViewById(R.id.tv_item_shoppingListpage);
        tv_purchase = (TextView) findViewById(R.id.tv_Pdate);
//        tv_members = (TextView) findViewById(R.id.tv_mem);
//        tv_quantity = (TextView) findViewById(R.id.tv_quan);



        searchableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if (!isFirstTimeClick) {
                    shoppingSpinnerList SHOPPING = items.get(i);
                    //tv_item.setText(SHOPPING.getItemSelected());
                    tv_duration.setText(SHOPPING.getPredictedDuration());
                    tv_finish.setText(SHOPPING.getFinishing_date());
                    tv_purchase.setText(SHOPPING.getPurchase_date());
                    //tv_members.setText(SHOPPING.getMembersSelected());
                    //tv_quantity.setText(SHOPPING.getQuantitySelected());
                }
                else {
                    isFirstTimeClick = false;
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



//        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
//            startActivity(new Intent(tryShowing.this, MainActivity.class));
//            finish();
//        }


        itemsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                List<shoppingSpinnerList> items = new ArrayList<>();

                for (DataSnapshot itemSnapShot:dataSnapshot.getChildren()) {
                    items.add(itemSnapShot.getValue(shoppingSpinnerList.class));
                }

                iFirebaseLoadDoneShoppingList.onFirebaseLoadShoppingListSuccess(items);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                iFirebaseLoadDoneShoppingList.onFirebaseLoadShoppingListFailed(databaseError.getMessage());
            }
        });


    }

    @Override
    public void onFirebaseLoadShoppingListSuccess(List<shoppingSpinnerList> shoppingSpinnerListList) {
        items = shoppingSpinnerListList;

        List<String> item_list = new ArrayList<>();

        for (shoppingSpinnerList item:shoppingSpinnerListList){
            item_list.add(item.getItemSelected());
        }
        //Log.i("kaisar", "onFirebaseLoadSuccess: " + name_list);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, item_list) ;
        searchableSpinner.setAdapter(adapter);

        selectedItem = searchableSpinner.getSelectedItem().toString();
    }

    @Override
    public void onFirebaseLoadShoppingListFailed(String message) {

    }
}
