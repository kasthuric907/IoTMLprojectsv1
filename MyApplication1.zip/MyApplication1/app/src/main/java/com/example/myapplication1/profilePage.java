package com.example.myapplication1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class profilePage extends AppCompatActivity {

    TextView tv_email, tv_name, tv_address;

    Button LOGOUT_btn, BACK_btn;
    //FirebaseAuth lougout_firebaseAuth;

    DatabaseReference DB_profileRef;

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);


        tv_email = (TextView) findViewById(R.id.tv_profilePage_email);
        tv_name = (TextView) findViewById(R.id.tv_profilePage_name);
        tv_address = (TextView) findViewById(R.id.tv_profilePage_address);

        LOGOUT_btn = (Button) findViewById(R.id.btn_LOGOUT);
        BACK_btn = (Button) findViewById(R.id.btn_back);

        DB_profileRef = FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getUid());

        DB_profileRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String name = dataSnapshot.child("fName").getValue().toString() + " " + dataSnapshot.child("lName").getValue().toString();
                String email = dataSnapshot.child("email").getValue().toString();
                String address = dataSnapshot.child("address").getValue().toString();

                tv_email.setText(  "Email : " + email);
                tv_name.setText(   "Name : " + name);
                tv_address.setText("Address : " + address);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        LOGOUT_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(profilePage.this, MainActivity.class));
                finish();
            }
        });

        BACK_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(profilePage.this, homePage.class));
                finish();
            }
        });
    }
}
