package com.example.myapplication1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication1.Interface.IFirebaseLoadDone;
import com.example.myapplication1.model.itemSpinnerList;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.MqttClient;

import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;

public class AddItems extends AppCompatActivity implements IFirebaseLoadDone {

    SearchableSpinner searchableSpinner;

    private FirebaseAuth addItem_FirebaseAuth;

    DatabaseReference itemsRef;
    IFirebaseLoadDone iFirebaseLoadDone;
    List<itemSpinnerList> items;

    Button btn_addItem, btn_regItem;
    EditText et_quantity, et_members;

    String selectedItem;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);
        searchableSpinner = (SearchableSpinner)findViewById(R.id.searchable_spinner_addItemsPage);

        btn_addItem = (Button) findViewById(R.id.btn_addItems_add);
        btn_regItem = (Button) findViewById(R.id.btn_reqItems_add);

        et_quantity = (EditText) findViewById(R.id.et_additems_quantity);
        et_members = (EditText) findViewById(R.id.et_additems_members);

        itemsRef = FirebaseDatabase.getInstance().getReference("Items");

        iFirebaseLoadDone = this;

        addItem_FirebaseAuth = FirebaseAuth.getInstance();
        //DBaddItemRef = FirebaseDatabase.getInstance().getReference("userInformatioin" + FirebaseAuth.getInstance().getUid());




        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(AddItems.this, MainActivity.class));
            finish();
        }

        itemsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                List<itemSpinnerList> items = new ArrayList<>();

                for (DataSnapshot itemSnapShot:dataSnapshot.getChildren()) {
                    items.add(itemSnapShot.getValue(itemSpinnerList.class));
                }

                iFirebaseLoadDone.onFirebaseLoadSuccess(items);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                iFirebaseLoadDone.onFirebaseLoadFailed(databaseError.getMessage());
            }
        });


        btn_addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Refrence
                //int n = Integer.parseInt(x.getText().toString());

                String selectedItem = searchableSpinner.getSelectedItem().toString();

                int selected_quantity = Integer.parseInt(et_quantity.getText().toString());
                int selected_members = Integer.parseInt(et_members.getText().toString());

                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                String purchase_date = df.format(Calendar.getInstance().getTime());

                //Log.i("selected quantity", "onClick: " + selected_quantity);
                //Log.i("selected members", "onClick: " + selected_members);

                addItemForm itemInfo = new addItemForm(selectedItem, selected_quantity, selected_members, purchase_date);

                if(selected_quantity < 1) {
                    Toast.makeText(AddItems.this, "Please enter the quantity.", Toast.LENGTH_SHORT).show();
                }
                else if (selected_members < 1) {
                    Toast.makeText(AddItems.this, "Please enter the number of members using it.", Toast.LENGTH_SHORT).show();
                }
                else {

                    //SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                    //String formattedDate = df.format(Calendar.getInstance().getTime());

                    //DateFormat tf = new SimpleDateFormat("h:mm a");
                    //String formattedTime = tf.format(Calendar.getInstance().getTime());

                    DateFormat dftf = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm:ss");
                    String dateTime = dftf.format(Calendar.getInstance().getTime());


                    //Log.i("Date", "onClick: " +formattedDate);

                    addItemForm itemForm = new addItemForm(selectedItem, selected_quantity, selected_members, purchase_date);

                    FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("itemsAdded").child(dateTime).setValue(itemInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            Toast.makeText(AddItems.this, "Item added Successfully.", Toast.LENGTH_SHORT).show();
                            //System.exit(0);
                        }
                    });


                    FirebaseDatabase.getInstance().getReference("userInformation").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("itemsHistory").child(dateTime).setValue(itemInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            Toast.makeText(AddItems.this, "Add another item.", Toast.LENGTH_SHORT).show();
                            //System.exit(0);
                        }
                    });

                    //String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());
                    //Log.i("date and time", "onClick: " + currentDateTimeString);

                }

            }
        });

        btn_regItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AddItems.this, ReqItem.class));
                finish();
            }
        });
    }

    @Override
    public void onFirebaseLoadSuccess(List<itemSpinnerList> itemSpinnerListList) {
        items = itemSpinnerListList;

        List<String> name_list = new ArrayList<>();

        for (itemSpinnerList item:itemSpinnerListList){
            name_list.add(item.getName());
        }
        //Log.i("kaisar", "onFirebaseLoadSuccess: " + name_list);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, name_list);
        searchableSpinner.setAdapter(adapter);

        selectedItem = searchableSpinner.getSelectedItem().toString();

    }



    @Override
    public void onFirebaseLoadFailed(String message) {

    }
}