package com.example.myapplication1;

public class signUpFormFB {

    public String fName, lName, email, address, psw;


    public signUpFormFB() {

    }

    public signUpFormFB(String fName, String lName, String email, String address, String psw) {
        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.address = address;
        this.psw = psw;
    }
}
