package com.example.myapplication1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.SoundPool;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class forgotPwd extends AppCompatActivity {

    EditText et_Email;
    Button btn_sndLink;

    private FirebaseAuth firebaseAuth_forgotPwd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pwd);

        et_Email = (EditText) findViewById(R.id.et_forgotPwd_Email);
        btn_sndLink = (Button) findViewById(R.id.btn_sndLink);

        firebaseAuth_forgotPwd = FirebaseAuth.getInstance();

        btn_sndLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strForgotPwdEmail = et_Email.getText().toString();

                if(TextUtils.isEmpty(strForgotPwdEmail)) {
                    Toast.makeText(forgotPwd.this, "Fill the EMAIL field.", Toast.LENGTH_SHORT).show();
                    return;
                }

                firebaseAuth_forgotPwd.sendPasswordResetEmail(strForgotPwdEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(forgotPwd.this, "Please check your inbox for passeord reset link.", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(forgotPwd.this, MainActivity.class));
                            finish();
                        }
                        else {
                            Toast.makeText(forgotPwd.this, "An error occured. Try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });


    }
}
